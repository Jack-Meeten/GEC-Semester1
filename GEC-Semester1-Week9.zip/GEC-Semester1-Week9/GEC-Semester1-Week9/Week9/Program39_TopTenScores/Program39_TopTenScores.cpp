#include <iostream>
#include <fstream>
#include <iomanip>

using namespace std;

//https://cplusplus.com/reference/fstream/

void EnterScore(ofstream* file);

struct scoreData
{
    int scores;
    string names;
};

int main()
{
    ofstream outScoresFile("scores.txt");

    ofstream* pOutScores = &outScoresFile;

    int userChoice;

	while (true)
	{
        cout << "Pick One of the following options : \n";
        cout << "1 . Enter a score\n";
        cout << "2 . Display scores\n";
        cout << "3 . Exit\n";

        cin >> userChoice;

        if (userChoice == 1)
        {
            EnterScore(pOutScores);
        }
	}

    //scoresFile.close();
    return 0;
}

void EnterScore(ofstream* file)
{

}
