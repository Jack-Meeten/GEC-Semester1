#include <iostream>

int main()
{
    int width = 15;
    int height = 25;
    int area = width * height;

    std::cout << "The Area of a " << width << " by " << height << " rectangle is " << area << "\n";
}
