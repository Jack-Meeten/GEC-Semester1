#include <iostream>

int main()
{
    std::cout << "Size of char: " << sizeof(char) << " bytes\n";
    std::cout << "Size of int: " << sizeof(int) << " bytes\n";
    std::cout << "Size of short int: " << sizeof(short int) << " bytes\n";
    std::cout << "Size of long int: " << sizeof(long int) << " bytes\n";
    std::cout << "Size of double: " << sizeof(double) << " bytes\n";
    std::cout << "Size of wChar_t: " << sizeof(wchar_t) << " bytes\n";

    return 0;
}
