#include <iostream>
using namespace std;

int main()
{
	int myInt1 = 5, myInt2;
	myInt2 = 10;

	cout << "Value stored in myInt1 is " << myInt1 << "\n";
	cout << "Value stored in myInt2 is " << myInt2 << "\n";


	int myFloat1 = 1.2f, myFloat2;
	myFloat2 = 9.9f;

	cout << "Value stored in myFloat1 is " << myFloat1 << "\n";
	cout << "Value stored in myFloat2 is " << myFloat2 << "\n";

	char myChar = 'a';

	cout << "Value stored in myChar is " << myChar << "\n";

	return 0;
}
