#include <iostream>
using namespace std;

int main()
{
    int mySavings = 2000;
    int yourPecentage = 50;
    int yourShare = (mySavings * yourPecentage) / 100;

    cout << "Your Share : " << yourShare << "\n";

    return 0;
}